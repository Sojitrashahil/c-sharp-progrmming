﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1_dimensional.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            int[] x;
            x = new int[5];
            Console.Write("Enter Elements:\n");
            for (i = 0; i < 5; i++)
            {
                Console.Write("\t Element[" + i + "]:");
                x[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.Write("\n \n Element are:\n");
            for (i = 0; i < 5; i++)
            {
                Console.WriteLine("\t Element[" + i + "]:" + x[i]);

            }
            Console.Read();
        }
    }
}
